
# ECMAscript 6 (ES6)
Node 基礎是js指令碼語言，
Node語法是js語法，只不過封裝了一些類別庫。

## 解析器 
指令碼語言都需要解析器。
js寫在html，解析器就是browser，js獨立執行，解析器就是node。

所以Node可以視為js的解析器。

# ES6 標準
ECMAScript 6 是js語言的標準，一開始便是針對js制定。
目標為使得js可以用來撰寫複雜的大型應用程式。
現泛指 5.1 版以後的js。


























































































