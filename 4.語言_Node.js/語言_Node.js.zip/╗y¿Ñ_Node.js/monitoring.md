https://geekflare.com/nodejs-monitoring-tools/

# PM2
## 安裝
npm install -g pm2
## 啟用服務
pm2 start <start-filename> --name myapp

## Web 界面上啟用實時監控
https://id.keymetrics.io/api/oauth/login
註冊、生成密鑰後，可連接服務至web介面。

# Sematext
