# Alternative JavaScript
擴充js之後產生的語言。