
# 基礎用法

```
// 匿名
let ex = class {
     constructor(a) {
          this.a = a;
     }
};
// 命名
let ex2 = class exampleClass {
     constructor(a) {
          this.a = a;
     }
}
```
### 宣告
```
let exClass = class{}; // 方法1
class exClass{}; // 方法2
```