```
// Get the week by date
function getWeek(pDateStr){
    let week = "";
    let dt = new Date(pDateStr);
    let weekDay = ["(日)", "(一)", "(二)", "(三)", "(四)", "(五)", "(六)"];
    if(weekDay[dt.getDay()] != undefined) week = weekDay[dt.getDay()];
    return week;
};

let DateStr = '2022/02/16 02:55'
let vWeek = getWeek(DateStr);
console.log(vWeek);
```