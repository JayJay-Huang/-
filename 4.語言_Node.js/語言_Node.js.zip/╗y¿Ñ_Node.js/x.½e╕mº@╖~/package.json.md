文件內容

    {
        "name": "nodedemo0530",
        "version": "1.0.0",
        "description": "",
        "main": "index.js",
        "scripts": {
            "test": "echo \"Error: no test specified\" && exit 1"
            },
        "author": "",
        "license": "ISC"
    }

